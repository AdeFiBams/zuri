print ("starting calculator")
first_num = input("enter the first number: ")
first_num = float(first_num)

operation = input('''
enter the desired operator
enter + for addition
enter - for subtraction
enter * for multiplication
enter / for division
enter $  for modulus
'''
)
second_num = input("enter the second number: ")
second_num = float(second_num)
if operation == "+":
    print(first_num + second_num)
elif operation == "-":
    print(first_num - second_num)
elif operation == "/":
    print(first_num / second_num)
elif operation == "*":
    print(first_num * second_num)
elif operation == "$":
    print(first_num % second_num)
        
else:
    print("you have entered an incorrect operator")

    
                