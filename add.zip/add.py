print("Addition of integers")
num1= int(input("Enter the first number: "))
num2= int (input("Enter the second number: "))
answer = num1 + num2
print (answer)

